# Python-to-Java File Mapping

| Original Flask source | Java equivalent in this milestone | Status |
|---|---|---|
| `app.py` | `Application.java`, `WebController.java`, `SecurityConfig.java` | App setup/routes/security configuration recreated in Spring Boot |
| `config.py` | `application.properties` | Port and upload limits migrated; secrets are not hard-coded |
| `models.py` (`User`) | `model/AgriUser.java`, `service/AgriSureService.java` | User fields and BCrypt authentication recreated; in-memory storage remains |
| `models.py` (`HARDCODED_PLANS`) | `model/InsurancePlan.java`, `service/AgriSureService.java` | Original demo plan IDs, names, premiums, coverage, duration and crops mapped |
| `forms.py` | `WebController.java` request validation | Main registration validation recreated; full WTForms parity pending |
| `main/routes.py` | `WebController.java` | Home, about, customer care |
| `auth/routes.py` | `WebController.java` | Registration, login and logout; forgot-password/email flow pending |
| `farmer/routes.py` | `WebController.java`, `FeatureController.java` | Core insurance, uploads, demo payment, profile and claims; some original pages are placeholders |
| `agent/routes.py` | `WebController.java` | Dashboard/claim screen skeleton; task lifecycle parity pending |
| `templates/base.html`, `templates/main/index.html` | `templates/index.html` and shared page layout | Home design adapted; not a literal 1:1 template conversion |
| Original Jinja2 templates | Thymeleaf templates in `src/main/resources/templates` | Core screens recreated; remaining templates need individual parity work |
| `static/css/style.css` | `static/css/style.css` | Copied from source where available |
| `static/js/script.js`, `agent-dashboard.js` | `static/js/` | Copied from source where available; DOM/template selectors need page-by-page verification |
| `static/images/agrisure-logo.png` | `static/images/agrisure-logo.png` | Copied from source |
| AI feature `service.py`, `aiService.js`, `model.pkl` | None yet | Uploaded feature files are zero bytes; executable model/service logic is missing |
| Solidity contracts in AI Features archive | None yet | Listed contract files are zero bytes in that archive; other separate contract source requires separate validation before integration |
| Database/schema | None | Original Flask app uses in-memory dictionaries; no database to migrate |

## Original routes discovered
- Main: `/`, `/about`, `/customer-care`
- Auth: `/login`, `/register`, `/logout`
- Farmer: `/dashboard`, `/risk-estimator`, `/insurance-plans`, `/select-plan/<plan_id>`, `/upload-documents/<plan_id>`, `/payment/<plan_id>`, `/my-insurances`, `/calculate-risk`, `/loan-services`, `/loan-document-upload`, `/loan-application-submitted`, `/subsidies`, `/my-profile`, `/file-claim`, `/update-profile`
- Agent: `/dashboard`, `/submit-task/<task_id>`, `/verify-claim/<claim_id>`, `/completed-tasks`

Some original template pages (weather forecast, crop health, subsidies, loan services) are present, but the original route source does not expose a fully working integration for every page.
