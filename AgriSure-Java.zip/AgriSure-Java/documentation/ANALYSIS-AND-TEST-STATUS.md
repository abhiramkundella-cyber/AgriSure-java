# Source Analysis and Verification Status

## Source inventory
The primary website source was found inside `AgriSure-AI-Crop-Insurance-main.zip` → `AGRISURE-PROJECT.zip` → `AgriSure-main/`. Excluding `venv/` and `__pycache__/`, the archive contains 48 project files, including Flask source, 25 Jinja2 templates, static CSS/JS/logo assets, requirements and deployment configuration.

A separate `AgriSure-main.zip` contains a different Node.js/Express and Solidity-oriented project. The separate `AgriSure-AI Features.zip` lists additional AI, backend, frontend and blockchain files, but the inspected files in that archive (including the three Python AI service files, JavaScript service/controller/model files, Solidity contract files and `model.pkl`) are zero bytes. Those files do not provide implementable source logic.

## Original stack detected
- Flask, Flask-Login, Flask-WTF, WTForms, Jinja2
- Bootstrap, custom CSS and JavaScript
- Python dictionaries for users, profiles, insurance, claims and agent tasks
- Werkzeug password hashing
- Local document uploads; file extension allow-list in config
- `requests` dependency listed, but no provider key/config was supplied

## Verification status
- Source archive and key files were inspected.
- Java source and Maven project structure were generated.
- Automated build/test has **not** been run in this environment because Maven is not installed (`mvn: command not found`). A working JDK 21 is present, but Spring Boot dependencies must be downloaded by Maven before compilation.
- Runtime startup, browser rendering, route integration, upload security, CSRF behavior, and workflow parity remain unverified until `mvn clean test` and manual smoke tests are run in an environment with Maven/dependency access.

## Known gaps
- No real database persistence; data resets at restart.
- No real payment gateway, email delivery, external weather provider, AI inference or blockchain connection.
- Agent task assignment/submission and claim review are not yet at feature parity.
- Some large original pages have explicit informational placeholders rather than invented functionality.
- The conversion is a staged milestone, not a claim of perfect feature parity.
