# AgriSure Java — staged Spring Boot conversion

This project is a Java/Spring Boot conversion milestone based on the supplied nested `AGRISURE-PROJECT.zip`, whose application README and source files identify Flask/Python, Flask-Login, Flask-WTF, Jinja2 templates, Bootstrap and in-memory dictionaries.

## Current conversion status

Implemented in this milestone:
- Spring Boot MVC application and Thymeleaf pages for home, about, customer care, registration/login/logout.
- In-memory user records, BCrypt password hashes and farmer/agent role checks at the route level.
- Insurance plan catalogue using the original plan IDs, names, premiums, coverages, terms and crop lists from `models.py`.
- Farmer dashboard, plan filtering, document upload, demo enrollment/payment, profile update and demo claim submission.
- Agent dashboard and informational claim verification page.
- Copied original CSS, JavaScript and AgriSure logo assets when present in the source archive.
- Explicit informational placeholders for weather, crop-health, loan and subsidy features whose integrations are not fully represented by executable source.

Not yet parity-complete:
- The original 25 Jinja2 templates have not all been ported one-to-one; the Java milestone supplies equivalent pages for core flows and clearly labels incomplete screens.
- Agent task assignment/submission and claim review are not fully reproduced.
- Weather provider, AI crop disease/yield/fraud models, external lender/subsidy APIs and blockchain are not implemented from the uploaded AI Features ZIP because those listed service/model files are zero bytes.
- Data is in memory and resets on restart, like the original demo. A database migration is not performed because the source application has no database schema/data to migrate.
- Real payment processing, email delivery and production-grade account recovery are not connected.

## Requirements
- JDK 21
- Maven 3.9+
- Internet access for Maven to download dependencies on first build

## Run
From this folder:

```bash
mvn clean test
mvn spring-boot:run
```

Then open `http://localhost:8080`.

For a packaged JAR:

```bash
mvn clean package
java -jar target/agrisure-java-1.0.0.jar
```

## Notes on security and data
- This is an educational prototype, not a real insurance product.
- Do not upload real identity or banking documents to an untrusted deployment.
- Uploads are saved under the local `uploads/` directory. Configure a private writable location before deployment.
- Use HTTPS, secure cookie settings, a persistent database, access-control review, malware scanning for uploads, audit logs and secret management before production use.
- No API keys or secrets from the original application are copied into this project.

## Main packages
- `com.agrisure.controller`: MVC routes
- `com.agrisure.service`: demo business logic and plan catalogue
- `com.agrisure.model`: Java data models
- `com.agrisure.config`: security and password encoder configuration
- `src/main/resources/templates`: Thymeleaf pages
- `src/main/resources/static`: retained frontend assets

See `documentation/FILE-MAPPING.md` for the Python-to-Java mapping and `documentation/ANALYSIS-AND-TEST-STATUS.md` for known limitations and verification status.
