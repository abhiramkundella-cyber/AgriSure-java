package com.agrisure.model;

import java.util.List;

public record InsurancePlan(String id, String name, String term, int premium, int coverage, String duration, List<String> crops) { }
