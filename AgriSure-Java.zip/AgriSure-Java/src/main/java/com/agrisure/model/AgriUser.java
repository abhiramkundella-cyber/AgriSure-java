package com.agrisure.model;

public class AgriUser {
    private String phone, name, passwordHash, profession, address, dob, district;
    public AgriUser(String phone, String name, String passwordHash, String profession, String address, String dob, String district) {
        this.phone=phone; this.name=name; this.passwordHash=passwordHash; this.profession=profession; this.address=address; this.dob=dob; this.district=district;
    }
    public String getPhone(){return phone;} public String getName(){return name;} public String getPasswordHash(){return passwordHash;}
    public String getProfession(){return profession;} public String getAddress(){return address;} public String getDob(){return dob;} public String getDistrict(){return district;}
    public void setName(String name){this.name=name;} public void setAddress(String address){this.address=address;} public void setDob(String dob){this.dob=dob;} public void setDistrict(String district){this.district=district;}
}
