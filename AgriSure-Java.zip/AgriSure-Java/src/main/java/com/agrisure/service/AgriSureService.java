package com.agrisure.service;

import com.agrisure.model.AgriUser;
import com.agrisure.model.InsurancePlan;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AgriSureService {
    private final Map<String, AgriUser> users = new ConcurrentHashMap<>();
    private final Map<String, List<Map<String,String>>> insuranceByPhone = new ConcurrentHashMap<>();
    private final Map<String, List<Map<String,String>>> claimsByPhone = new ConcurrentHashMap<>();
    private final PasswordEncoder encoder;
    public AgriSureService(PasswordEncoder encoder) { this.encoder=encoder; }

    private static final List<InsurancePlan> PLANS = List.of(
      new InsurancePlan("S1","Basic Kharif Cover","Short",1200,25000,"3-4 Months",List.of("Rice","Soybean")),
      new InsurancePlan("S2","Medium Kharif Secure","Short",1800,40000,"3-4 Months",List.of("Cotton","Maize")),
      new InsurancePlan("S3","Quick Veggie Guard","Short",1000,20000,"2-3 Months",List.of("Tomato","Onion")),
      new InsurancePlan("S4","Monsoon Pulse Shield","Short",1400,30000,"3 Months",List.of("Moong","Urad")),
      new InsurancePlan("S5","Rabi Weather Shield","Short",1500,35000,"4 Months",List.of("Mustard","Gram")),
      new InsurancePlan("M1","Standard Mid Term Protect","Mid",2800,60000,"6 Months",List.of("Sugarcane","Banana")),
      new InsurancePlan("M2","Enhanced Growth Secure","Mid",3500,75000,"5-7 Months",List.of("Turmeric","Ginger")),
      new InsurancePlan("M3","Orchard Bloom Guard","Mid",4000,90000,"6-8 Months",List.of("Mango","Guava")),
      new InsurancePlan("M4","Cotton Boll Protect","Mid",3200,70000,"6 Months",List.of("Cotton")),
      new InsurancePlan("M5","Extended Growth Plan","Mid",3000,65000,"5-6 Months",List.of("Pulses","Groundnut")),
      new InsurancePlan("L1","Annual Crop Shield","Long",5500,120000,"1 Year",List.of("Plantation Crops","Coconut")),
      new InsurancePlan("L2","Perennial Plant Guard","Long",6500,150000,"1 Year",List.of("Tea","Coffee","Rubber")),
      new InsurancePlan("L3","Forestry Secure Plan","Long",8000,180000,"1 Year+",List.of("Timber","Bamboo")),
      new InsurancePlan("L4","Vineyard Annual Cover","Long",7000,160000,"1 Year",List.of("Grapes")),
      new InsurancePlan("L5","Farm Asset Annual Plan","Long",7500,160000,"1 Year",List.of("Mixed Farming","Arecanut"))
    );
    public synchronized String register(String name,String phone,String password,String profession,String address,String dob,String district) {
        if(users.containsKey(phone)) return "Phone number already registered.";
        if(name==null||name.trim().length()<2) return "Please enter a valid full name.";
        if(phone==null||!phone.matches("^\\+?1?\\d{9,15}$")) return "Please enter a valid phone number.";
        if(password==null||password.length()<6) return "Password must contain at least 6 characters.";
        if(!List.of("Farmer","Agent").contains(profession)) return "Choose Farmer or Agent.";
        if("Agent".equals(profession)&&(district==null||district.isBlank())) return "Please select a district for agent registration.";
        users.put(phone,new AgriUser(phone,name,encoder.encode(password),profession,address,dob,district));
        insuranceByPhone.put(phone,new ArrayList<>()); claimsByPhone.put(phone,new ArrayList<>());
        return null;
    }
    public AgriUser authenticate(String phone,String password,String profession) {
        AgriUser u=users.get(phone);
        return u!=null && u.getProfession().equals(profession) && encoder.matches(password,u.getPasswordHash()) ? u : null;
    }
    public AgriUser user(String phone){return users.get(phone);}
    public Collection<InsurancePlan> plans(String term){return PLANS.stream().filter(p->term==null||term.isBlank()||p.term().equalsIgnoreCase(term)).toList();}
    public InsurancePlan plan(String id){return PLANS.stream().filter(p->p.id().equals(id)).findFirst().orElse(null);}
    public List<Map<String,String>> insurances(String phone){return insuranceByPhone.computeIfAbsent(phone,k->new ArrayList<>());}
    public synchronized void enroll(String phone,InsurancePlan p,String receipt){
        Map<String,String> row=new LinkedHashMap<>(); row.put("id", "INS-"+UUID.randomUUID().toString().substring(0,8).toUpperCase()); row.put("planId",p.id()); row.put("planName",p.name()); row.put("premium",String.valueOf(p.premium())); row.put("coverage",String.valueOf(p.coverage())); row.put("status","Active (demo)"); row.put("receipt",receipt); insurances(phone).add(row);
    }
    public List<Map<String,String>> claims(String phone){return claimsByPhone.computeIfAbsent(phone,k->new ArrayList<>());}
    public synchronized void addClaim(String phone,String insuranceId,String description){Map<String,String> c=new LinkedHashMap<>(); c.put("id","CLM-"+UUID.randomUUID().toString().substring(0,8).toUpperCase()); c.put("insuranceId",insuranceId); c.put("description",description); c.put("status","Submitted (demo)"); claims(phone).add(c);}
}
