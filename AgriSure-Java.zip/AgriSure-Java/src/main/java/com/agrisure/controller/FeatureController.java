package com.agrisure.controller;

import com.agrisure.model.AgriUser;
import com.agrisure.service.AgriSureService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/farmer")
public class FeatureController {
    private final AgriSureService service;
    public FeatureController(AgriSureService service){this.service=service;}
    private String check(HttpSession s,RedirectAttributes f){Object phone=s.getAttribute("phone");if(phone==null){f.addFlashAttribute("error","Please log in as a farmer to continue.");return "redirect:/login";}AgriUser u=service.user(phone.toString());if(u==null||!"Farmer".equals(u.getProfession())){f.addFlashAttribute("error","This feature is available to farmer accounts.");return "redirect:/";}return null;}
    private String show(String title,String description,Model m,HttpSession s,RedirectAttributes f){String gate=check(s,f);if(gate!=null)return gate;m.addAttribute("user",service.user(s.getAttribute("phone").toString()));m.addAttribute("featureTitle",title);m.addAttribute("featureDescription",description);return "feature";}
    @GetMapping("/loan-services") public String loans(Model m,HttpSession s,RedirectAttributes f){return show("Loan Services","The original website provides a loan-services information page. Loan-provider integration and eligibility decisions are not connected in this Java demo.",m,s,f);}
    @GetMapping("/loan-document-upload") public String loanDocs(Model m,HttpSession s,RedirectAttributes f){return show("Loan Document Upload","Document-upload workflow for loan applications is pending conversion from the original large Jinja template.",m,s,f);}
    @GetMapping("/loan-application-submitted") public String loanSubmitted(Model m,HttpSession s,RedirectAttributes f){return show("Loan Application Status","This page is a demo status page; no lender submission is connected.",m,s,f);}
    @GetMapping("/subsidies") public String subsidies(Model m,HttpSession s,RedirectAttributes f){return show("Subsidies","The original website includes a subsidy information page. External scheme data and eligibility verification are not connected.",m,s,f);}
    @GetMapping("/weather-forecast") public String weather(Model m,HttpSession s,RedirectAttributes f){return show("Weather Forecast","Weather integration requires valid provider configuration. No API key or verified weather service was supplied with the source files.",m,s,f);}
    @GetMapping("/weather-alerts") public String alerts(Model m,HttpSession s,RedirectAttributes f){return show("Weather Alerts","The original weather-alert template is empty and no active alert integration was supplied.",m,s,f);}
    @GetMapping("/crop-health") public String cropHealth(Model m,HttpSession s,RedirectAttributes f){return show("Crop Health","The original project includes a crop-health template, but no working crop-disease model was provided in the AI-feature archive.",m,s,f);}
    @GetMapping("/upload-documents") public String documents(Model m,HttpSession s,RedirectAttributes f){return show("Upload Documents","Choose an insurance plan first to open its document-upload workflow.",m,s,f);}
}
